import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { formatProjectCode, cleanProjectCode } from '../utils/formatting';
import { ArrowRight } from 'lucide-react';

export const WorkerJoin: React.FC = () => {
  const navigate = useNavigate();
  const { setPendingWorkerCode, masterProject } = useApp();

  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 9);
    setCode(raw);
    if (error) setError(null);
  };

  const handleUseMasterCode = () => {
    if (masterProject?.projectCode) {
      setCode(masterProject.projectCode);
      if (error) setError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = cleanProjectCode(code);

    if (clean.length !== 9) {
      setError('Please enter a valid 9-digit project code.');
      return;
    }

    // Validate against Master project if one exists in demo
    if (masterProject && masterProject.projectCode && masterProject.projectCode !== clean) {
      setError(`Project ${clean} not found. Active Master project code is ${formatProjectCode(masterProject.projectCode)}.`);
      return;
    }

    setPendingWorkerCode(clean);
    navigate('/worker/allocation');
  };

  return (
    <div className="page-container centered">
      <div className="join-container">
        <h1 style={{ fontSize: '22px', fontWeight: 600, marginBottom: '8px' }}>
          Join a Project
        </h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>
          Enter the 9-digit project code provided by your cluster Master.
        </p>

        <form onSubmit={handleSubmit} className="code-input-group">
          <div>
            <input
              type="text"
              className="code-input"
              placeholder="000 000 000"
              value={formatProjectCode(code)}
              onChange={handleInputChange}
              maxLength={11}
              autoFocus
            />
            {error && <p className="input-error">{error}</p>}
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-block"
            disabled={code.length !== 9}
          >
            <span>Enter</span>
            <ArrowRight size={16} />
          </button>
        </form>

        {masterProject?.projectCode && (
          <div
            style={{
              marginTop: '16px',
              padding: '10px 14px',
              backgroundColor: 'var(--bg-secondary)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-md)',
              fontSize: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <span style={{ color: 'var(--text-secondary)' }}>
              Online Demo Master: <strong>{formatProjectCode(masterProject.projectCode)}</strong>
            </span>
            <button
              type="button"
              className="btn btn-secondary btn-sm"
              onClick={handleUseMasterCode}
              style={{ padding: '3px 8px', fontSize: '11px' }}
            >
              Fill Code
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
